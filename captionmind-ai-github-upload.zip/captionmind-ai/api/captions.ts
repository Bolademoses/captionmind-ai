import type { VercelRequest, VercelResponse } from "@vercel/node";

const PLATFORMS = ["instagram", "linkedin", "tiktok", "facebook", "x", "whatsapp"];
const TONES = [
  "Authoritative","Objective","Diplomatic","Concise","Formal","Consultative","Pragmatic","Inquisitive","Didactic","Transparent","Clinical","Visionary",
  "Urgent","Assertive","Inspirational","Provocative","Enthusiastic","Compelling","Evangelical","Incentivizing","Challenging","Unapologetic","Dynamic","Aspirational",
  "Empathetic","Conversational","Encouraging","Vulnerable","Grateful","Collegial","Reassuring","Nurturing","Apologetic","Humble","Intimate","Inclusive","Sincere",
  "Witty","Sardonic","Playful","Deadpan","Poetic","Nostalgic","Dramatic","Philosophical","Irreverent","Suspenseful","Satirical","Whimsical","Stoic"
];
const LENGTHS = ["Short", "Medium", "Long"];
const COUNTS = [3, 5, 8];
const MIME_TYPES = ["image/jpeg", "image/png", "image/webp"];

type Media = { mimeType: string; data: string };

function fail(res: VercelResponse, status: number, message: string) {
  return res.status(status).json({ error: message });
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") return fail(res, 405, "Method not allowed.");
  if (!process.env.OPENAI_API_KEY) return fail(res, 503, "The AI service is not configured yet.");

  try {
    const body = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
    const platform = String(body?.platform || "");
    const tone = String(body?.tone || "");
    const count = Number(body?.count);
    const length = String(body?.length || "");
    const lenses = Array.isArray(body?.lenses) ? body.lenses.slice(0, 12).map(String) : [];
    const media: Media[] = Array.isArray(body?.media) ? body.media : [];

    if (!PLATFORMS.includes(platform)) return fail(res, 400, "Choose a supported social platform.");
    if (!TONES.includes(tone)) return fail(res, 400, "Choose a supported writing tone.");
    if (!COUNTS.includes(count)) return fail(res, 400, "Choose 3, 5 or 8 caption variations.");
    if (!LENGTHS.includes(length)) return fail(res, 400, "Choose Short, Medium or Long caption length.");
    if (!media.length || media.length > 5) return fail(res, 400, "Upload between one and five visual frames.");
    let total = 0;
    for (const item of media) {
      if (!MIME_TYPES.includes(item.mimeType) || typeof item.data !== "string" || !/^[A-Za-z0-9+/=]+$/.test(item.data)) {
        return fail(res, 400, "One of the uploaded images has an unsupported format.");
      }
      total += item.data.length;
    }
    if (total > 3_700_000) return fail(res, 413, "The uploaded media is too large. Compress it and try again.");

    const whatsappFormat = String(body?.whatsappFormat || "Status");
    const audience = String(body?.audience || "").slice(0, 500);
    const context = String(body?.context || "").slice(0, 1500);
    const system = `You are CaptionMind AI, an expert social copywriter and visual analyst. Analyse only what is visible in the supplied images. Do not claim facts that cannot be verified from the visual or user context. Produce distinct, useful captions rather than superficial rewrites. Match the platform's conventions and the requested tone. Avoid generic AI phrases, engagement bait and unnecessary emoji. Hashtags must be relevant and limited to five. Return exactly the requested number of variations.`;
    const platformInstructions: Record<string,string> = {
      instagram: "Write for Instagram: strong first line, easy mobile scanning, relevant discovery hashtags.",
      linkedin: "Write for LinkedIn: professional but human, clear insight, natural paragraphing, avoid corporate clichés.",
      tiktok: "Write for TikTok: immediate hook, conversational language, concise context and a natural next step.",
      facebook: "Write for Facebook: relatable, accessible, community-aware copy.",
      x: "Write for X: concise, high-signal copy that respects tight attention and character limits.",
      whatsapp: `Write for WhatsApp ${whatsappFormat}: ${whatsappFormat === "Status" ? "short, personal, status-friendly, broken into compact lines" : whatsappFormat === "Channels" ? "broadcast-style channel update, clear and useful" : whatsappFormat === "Direct message" ? "natural one-to-one message, not an advertisement" : "broadcast message that feels personal, concise and respectful"}.`
    };
    const prompt = `Create ${count} distinct ${length.toLowerCase()} caption variations for ${platform}.
Writing tone: ${tone}.
Reasoning lenses to apply: ${lenses.length ? lenses.join(", ") : "Use balanced strategic, creative and audience-aware reasoning"}.
Target audience: ${audience || "Infer the most likely audience from the visual without overclaiming"}.
Additional context/objective: ${context || "No extra context supplied. Let the visual lead."}
Platform guidance: ${platformInstructions[platform]}
For each variation provide:
- text: complete ready-to-publish caption
- angle: short label describing the creative angle
- platformTip: one concise platform-specific recommendation
- hashtags: array of zero to five hashtag terms without #.
Do not include labels like "Caption:" inside the text. Make the variations meaningfully different.`;

    const content: any[] = [{ type: "text", text: prompt }];
    for (const item of media) content.push({ type: "image_url", image_url: { url: `data:${item.mimeType};base64,${item.data}`, detail: "low" } });

    const model = process.env.OPENAI_MODEL || "gpt-4.1-mini";
    const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        temperature: 0.85,
        max_tokens: 3600,
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "caption_variations",
            strict: true,
            schema: {
              type: "object",
              additionalProperties: false,
              properties: {
                captions: {
                  type: "array",
                  minItems: count,
                  maxItems: count,
                  items: {
                    type: "object",
                    additionalProperties: false,
                    properties: {
                      text: { type: "string" },
                      angle: { type: "string" },
                      platformTip: { type: "string" },
                      hashtags: { type: "array", items: { type: "string" }, maxItems: 5 }
                    },
                    required: ["text", "angle", "platformTip", "hashtags"]
                  }
                }
              },
              required: ["captions"]
            }
          }
        },
        messages: [
          { role: "system", content: system },
          { role: "user", content }
        ]
      })
    });

    if (openaiResponse.status === 429) return fail(res, 429, "Generation is busy right now. Wait a moment and try again.");
    if (!openaiResponse.ok) {
      const status = openaiResponse.status;
      if (status === 401 || status === 403) return fail(res, 503, "The AI service credentials need to be checked.");
      return fail(res, 502, "Caption generation failed. Please try again shortly.");
    }
    const result: any = await openaiResponse.json();
    const raw = result?.choices?.[0]?.message?.content;
    if (!raw) return fail(res, 502, "The AI returned an empty response. Please try again.");
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed.captions)) return fail(res, 502, "The AI response was not in the expected format.");
    return res.status(200).json(parsed);
  } catch {
    return fail(res, 400, "The request could not be processed. Check the uploaded media and try again.");
  }
}