import { useMemo, useRef, useState } from "react";
import { Sparkles, UploadCloud, Copy, Check, Image as ImageIcon, Brain } from "lucide-react";

type MediaItem = { mimeType: string; data: string; name: string };
type Caption = { text: string; angle: string; platformTip: string; hashtags: string[] };

const tones = [
  "Authoritative","Objective","Diplomatic","Concise","Formal","Consultative","Pragmatic","Inquisitive","Didactic","Transparent","Clinical","Visionary",
  "Urgent","Assertive","Inspirational","Provocative","Enthusiastic","Compelling","Evangelical","Incentivizing","Challenging","Unapologetic","Dynamic","Aspirational",
  "Empathetic","Conversational","Encouraging","Vulnerable","Grateful","Collegial","Reassuring","Nurturing","Apologetic","Humble","Intimate","Inclusive","Sincere",
  "Witty","Sardonic","Playful","Deadpan","Poetic","Nostalgic","Dramatic","Philosophical","Irreverent","Suspenseful","Satirical","Whimsical","Stoic"
];

const lensGroups: Record<string,string[]> = {
  "Strategic thinking": ["First-Principles Thinking","Second-Order Thinking","Systems Thinking","Strategic Foresight","Inversion","Opportunity Cost","Pareto Principle","Root-Cause Analysis","Constraint Mapping","Leverage Analysis","Decision Theory","Game Theory","Scenario Planning","Risk Assessment","SWOT Analysis","Competitive Analysis","Blue Ocean Thinking","Jobs-to-be-Done","Value Chain Analysis","Moat Analysis"],
  "Creative thinking": ["Lateral Thinking","Divergent Thinking","Convergent Thinking","Design Thinking","Analogical Reasoning","Conceptual Blending","SCAMPER","Reverse Thinking","Random Entry","Six Thinking Hats","Morphological Analysis","Reframing","Association Thinking","Provocation","Abductive Reasoning","Possibility Thinking","Boundary-Pushing","Cross-Pollination","Storyboarding","Metaphorical Thinking","What-If Thinking","Visual Thinking","Constraint-Based Creativity","Mash-Up Thinking","Provocative Questions"],
  "Human & behavioral": ["Emotional Intelligence (EQ)","Empathy Mapping","Behavioral Economics","Cognitive Bias Analysis","Motivational Psychology","Social Proof","Loss Aversion","Curiosity Gap","Identity-Based Motivation","Audience Psychology","Cultural Context","Trust Building","Narrative Transportation","Community Dynamics","Status & Belonging","Cognitive Load","Friction Analysis","Habit Formation","Ethical Persuasion","Conversational Intelligence","Self-Determination Theory","Social Identity Theory","Peak-End Rule","Reciprocity Principle","Commitment & Consistency"],
  "Communication & analysis": ["Rhetorical Analysis","Narrative Structure","Clarity First","Signal-to-Noise","Evidence-Based Reasoning","Claim-Evidence-Impact","Precision Framing","Tone Calibration","Audience Segmentation","Message-Market Fit","Information Hierarchy","Contrast Principle","Specificity Effect","Semantic Framing","Objection Handling","Critical Thinking","Socratic Questioning","Funnel Thinking","Conversion Psychology","Memorability Design","Plain-Language Editing","Message Testing","Proof-Point Selection","Objection Mapping","Editorial Judgment"]
};
const lenses = Object.values(lensGroups).flat();
const platforms = ["Instagram","LinkedIn","TikTok","Facebook","X","WhatsApp"];
const platformValues: Record<string,string> = {Instagram:"instagram",LinkedIn:"linkedin",TikTok:"tiktok",Facebook:"facebook",X:"x",WhatsApp:"whatsapp"};

function base64FromDataUrl(dataUrl: string) { return dataUrl.split(",")[1] || ""; }

async function imageToPayload(file: File): Promise<MediaItem> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 960 / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not process the selected image.");
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  const blob = await new Promise<Blob>((resolve,reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error("Image compression failed.")), "image/jpeg", .68));
  const dataUrl = await new Promise<string>((resolve,reject) => { const r = new FileReader(); r.onload = () => resolve(String(r.result)); r.onerror = () => reject(new Error("Could not read image.")); r.readAsDataURL(blob); });
  return { mimeType:"image/jpeg", data:base64FromDataUrl(dataUrl), name:file.name };
}

async function sampleVideo(file: File): Promise<MediaItem[]> {
  const url = URL.createObjectURL(file);
  try {
    const video = document.createElement("video");
    video.preload = "metadata"; video.muted = true; video.src = url;
    await new Promise<void>((resolve,reject) => { video.onloadedmetadata=()=>resolve(); video.onerror=()=>reject(new Error("This video format could not be opened by your browser.")); });
    const duration = video.duration;
    if (!Number.isFinite(duration) || duration <= 0) throw new Error("The video duration could not be read.");
    const times = Array.from({length:Math.min(5,Math.max(1,Math.ceil(duration/8)))},(_,i)=>Math.min(duration*.92, Math.max(.1, duration*(i+1)/(Math.min(5,Math.max(1,Math.ceil(duration/8)))+1))));
    const frames: MediaItem[] = [];
    for (const time of times) {
      video.currentTime = time;
      await new Promise<void>((resolve,reject)=>{video.onseeked=()=>resolve();video.onerror=()=>reject(new Error("Could not sample a video frame."));});
      const scale=Math.min(1,960/Math.max(video.videoWidth,video.videoHeight));
      const canvas=document.createElement("canvas");canvas.width=Math.round(video.videoWidth*scale);canvas.height=Math.round(video.videoHeight*scale);
      const ctx=canvas.getContext("2d");if(!ctx) continue;ctx.drawImage(video,0,0,canvas.width,canvas.height);
      const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(new Error("Video frame compression failed.")),"image/jpeg",.62));
      const dataUrl=await new Promise<string>((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result));r.onerror=()=>reject(new Error("Could not read video frame."));r.readAsDataURL(blob);});
      frames.push({mimeType:"image/jpeg",data:base64FromDataUrl(dataUrl),name:`${file.name} frame`});
    }
    return frames;
  } finally { URL.revokeObjectURL(url); }
}

export default function App() {
  const inputRef=useRef<HTMLInputElement>(null);
  const [media,setMedia]=useState<MediaItem[]>([]);
  const [fileNames,setFileNames]=useState<string[]>([]);
  const [platform,setPlatform]=useState("LinkedIn");
  const [tone,setTone]=useState("Conversational");
  const [count,setCount]=useState("3");
  const [length,setLength]=useState("Medium");
  const [audience,setAudience]=useState("");
  const [context,setContext]=useState("");
  const [whatsappFormat,setWhatsappFormat]=useState("Status");
  const [selectedLenses,setSelectedLenses]=useState<string[]>(["First-Principles Thinking","Lateral Thinking","Emotional Intelligence (EQ)"]);
  const [captions,setCaptions]=useState<Caption[]>([]);
  const [busy,setBusy]=useState(false);
  const [error,setError]=useState("");
  const [copied,setCopied]=useState<number|null>(null);
  const [lensGroup,setLensGroup]=useState("Strategic thinking");

  const totalBytes=useMemo(()=>media.reduce((n,m)=>n+m.data.length,0),[media]);
  function toggleLens(name:string){setSelectedLenses(old=>old.includes(name)?old.filter(x=>x!==name):old.length>=12?old:[...old,name]);}
  async function handleFiles(list:FileList|null){
    if(!list)return;
    setError("");setCaptions([]);
    try{
      const next:MediaItem[]=[];const names:string[]=[];
      for(const file of Array.from(list)){
        if(file.type.startsWith("image/")){if(!["image/jpeg","image/png","image/webp"].includes(file.type))throw new Error("Use JPEG, PNG or WebP images.");next.push(await imageToPayload(file));names.push(file.name);}
        else if(file.type.startsWith("video/")){const frames=await sampleVideo(file);next.push(...frames);names.push(`${file.name} (${frames.length} sampled frames)`);}
        else throw new Error("Upload an image or a supported video file.");
      }
      if(next.length>5)throw new Error("Use up to five images or sampled video frames in total.");
      const bytes=next.reduce((n,m)=>n+m.data.length,0);
      if(bytes>3_700_000)throw new Error("The compressed media is too large. Try a smaller image or shorter video.");
      setMedia(next);setFileNames(names);
    }catch(e){setMedia([]);setFileNames([]);setError(e instanceof Error?e.message:"Could not process that file.");}
  }
  async function generate(){
    if(!media.length){setError("Upload an image or video first.");return;}
    setBusy(true);setError("");setCaptions([]);
    try{
      const response=await fetch("/api/captions",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
        platform:platformValues[platform],tone,lenses:selectedLenses,count:Number(count),length,audience,context,whatsappFormat,
        media:media.map(({mimeType,data})=>({mimeType,data}))
      })});
      const payload=await response.json();
      if(!response.ok)throw new Error(payload.error||"Caption generation failed. Please try again.");
      setCaptions(payload.captions||[]);
      if(!payload.captions?.length)throw new Error("The AI returned no captions. Please try again.");
    }catch(e){setError(e instanceof Error?e.message:"Something went wrong.");}
    finally{setBusy(false);}
  }
  async function copy(text:string,index:number){await navigator.clipboard.writeText(text);setCopied(index);setTimeout(()=>setCopied(null),1500);}
  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark">C</div><div><div className="brand-name">CaptionMind AI</div><div className="brand-sub">Think deeper. Write sharper.</div></div></div>
      <div className="pill"><Sparkles size={13} style={{verticalAlign:"-2px",marginRight:5}}/> AI caption studio</div>
    </header>
    <section className="hero"><div className="eyebrow">Social content, with intention</div><h1>One visual. <span className="gradient">A hundred ways</span> to tell the story.</h1><p>Upload a photo or video. CaptionMind studies the visual, applies your chosen reasoning lenses and writing tone, then creates platform-ready captions that sound like you.</p></section>
    <main className="layout">
      <section className="panel">
        <h2><ImageIcon size={17} style={{verticalAlign:"-3px",marginRight:8,color:"#79aaff"}}/>Your content & direction</h2>
        <label className="dropzone" onClick={()=>inputRef.current?.click()}><UploadCloud size={25}/><strong>Upload image or video</strong><small>JPEG, PNG, WebP or browser-supported video · up to 5 visual frames</small><input ref={inputRef} hidden type="file" accept="image/jpeg,image/png,image/webp,video/*" multiple onChange={e=>handleFiles(e.target.files)}/></label>
        {fileNames.length>0&&<div className="filelist">{fileNames.join(" · ")}</div>}
        <div className="two">
          <div className="field"><label>Platform</label><select value={platform} onChange={e=>setPlatform(e.target.value)}>{platforms.map(p=><option key={p}>{p}</option>)}</select></div>
          <div className="field"><label>Writing tone</label><select value={tone} onChange={e=>setTone(e.target.value)}>{tones.map(t=><option key={t}>{t}</option>)}</select></div>
        </div>
        {platform==="WhatsApp"&&<div className="field"><label>WhatsApp format</label><select value={whatsappFormat} onChange={e=>setWhatsappFormat(e.target.value)}>{["Status","Channels","Direct message","Broadcast message"].map(x=><option key={x}>{x}</option>)}</select></div>}
        <div className="two">
          <div className="field"><label>Number of variations</label><select value={count} onChange={e=>setCount(e.target.value)}>{["3","5","8"].map(x=><option key={x}>{x}</option>)}</select></div>
          <div className="field"><label>Caption length</label><select value={length} onChange={e=>setLength(e.target.value)}>{["Short","Medium","Long"].map(x=><option key={x}>{x}</option>)}</select></div>
        </div>
        <div className="field"><label>Who are you speaking to? <span className="muted">(optional)</span></label><input type="text" value={audience} onChange={e=>setAudience(e.target.value)} placeholder="e.g. ecommerce founders, first-time buyers"/></div>
        <div className="field"><label>Extra context or objective <span className="muted">(optional)</span></label><textarea value={context} onChange={e=>setContext(e.target.value)} placeholder="What should the audience understand, feel or do? Add campaign details or a call to action."/></div>
        <div className="field">
          <label><Brain size={14} style={{verticalAlign:"-3px",marginRight:5,color:"#79aaff"}}/>Reasoning lenses <span className="muted">({selectedLenses.length}/12 selected)</span></label>
          <select value={lensGroup} onChange={e=>setLensGroup(e.target.value)}>{Object.keys(lensGroups).map(g=><option key={g}>{g}</option>)}</select>
          <div className="chips" style={{marginTop:10}}>{lensGroups[lensGroup].map(l=><button type="button" key={l} className={`chip ${selectedLenses.includes(l)?"active":""}`} onClick={()=>toggleLens(l)}>{l}</button>)}</div>
          <div className="muted" style={{marginTop:7}}>100 reasoning lenses across four categories. Select up to 12 for each generation.</div>
        </div>
        <button className="primary" onClick={generate} disabled={busy||!media.length}>{busy?"Thinking through your content…":<><Sparkles size={16} style={{verticalAlign:"-3px",marginRight:8}}/>Generate captions</>}</button>
        {error&&<div className="error">{error}</div>}
        <p className="muted">Video is analysed using up to five sampled frames. Soundtrack and spoken dialogue are not transcribed.</p>
      </section>
      <section className="panel">
        <h2>Generated captions</h2>
        {!captions.length&&!busy&&<div className="result-empty"><div><Sparkles size={30}/><strong>Your captions will appear here</strong><span className="muted">Upload a visual, choose your direction and generate.</span></div></div>}
        {busy&&<div className="result-empty"><div><Sparkles size={30}/><strong>Reading the visual and shaping your message</strong><span className="muted">Applying your selected lenses and tone…</span></div></div>}
        <div className="result-list">{captions.map((c,i)=><article className="result-card" key={i}>
          <div className="result-head"><strong>Variation {i+1}</strong><span className="angle">{c.angle}</span></div>
          <p>{c.text}</p>
          {c.hashtags?.length>0&&<div className="tags">{c.hashtags.map(h=>`#${h.replace(/^#/,"")}`).join(" ")}</div>}
          <button className="copy" onClick={()=>copy(`${c.text}${c.hashtags?.length?`\n\n${c.hashtags.map(h=>`#${h.replace(/^#/,"")}`).join(" ")}`:""}`,i)}>{copied===i?<Check size={12}/>:<Copy size={12}/>} {copied===i?"Copied":"Copy caption"}</button>
          {c.platformTip&&<div className="muted" style={{marginTop:10}}>Platform note: {c.platformTip}</div>}
        </article>)}</div>
      </section>
    </main>
    <footer>Powered by <strong style={{color:"#9abfff"}}>Tollerman</strong></footer>
  </div>;
}
